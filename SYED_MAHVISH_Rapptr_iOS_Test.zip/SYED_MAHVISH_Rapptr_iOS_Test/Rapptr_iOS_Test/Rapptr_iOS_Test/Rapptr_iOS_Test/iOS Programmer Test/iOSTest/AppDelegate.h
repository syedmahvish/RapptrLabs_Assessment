//
//  AppDelegate.h
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

