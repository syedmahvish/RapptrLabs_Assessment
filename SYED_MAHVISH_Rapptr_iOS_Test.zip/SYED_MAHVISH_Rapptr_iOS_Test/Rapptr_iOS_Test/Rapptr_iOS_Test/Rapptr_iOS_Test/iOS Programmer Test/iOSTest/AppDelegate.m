//
//  AppDelegate.m
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

#import "AppDelegate.h"
#import "iOSTest-Swift.h"

@interface AppDelegate ()
@property (nonatomic, strong) UINavigationController *navController;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [self.window makeKeyAndVisible];
    
    MenuViewController *mainMenuViewController = [[MenuViewController alloc] initWithNibName:@"MenuViewController" bundle:nil];
    
    self.navController = [[UINavigationController alloc] initWithRootViewController:mainMenuViewController];
   
        //set background color

    [[UINavigationBar appearance] setBarTintColor:[UIColor colorWithRed:14/255.0 green:92/255.0 blue:137/255.0 alpha:1.0]];
    
        //set font
    
    
    [[UINavigationBar appearance] setTitleTextAttributes: [NSDictionary dictionaryWithObjectsAndKeys:
                                                           [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0], NSForegroundColorAttributeName,
                                                           [UIFont systemFontOfSize:17 weight:UIFontWeightSemibold], NSFontAttributeName, nil]];
    
        //set back button with white color and no tittle.
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    
    [[UIBarButtonItem appearance] setTitleTextAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:0.1],
                                                           NSForegroundColorAttributeName: [UIColor clearColor] }
                                                forState:UIControlStateNormal];
    
        //set height to 64px.
    CGRect frame = self.navController.navigationBar.frame;
    [[UINavigationBar appearance] setFrame: CGRectMake(frame.origin.x, frame.origin.y, 64, frame.size.width)];
    
    self.navController = [[UINavigationController alloc] initWithRootViewController:mainMenuViewController];
    [self.navController setNavigationBarHidden:NO];
    
    self.window.rootViewController = self.navController;

    return YES;
}

@end
