//
//  AnimationViewController.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit

class AnimationViewController: UIViewController {
    
    /**
     * =========================================================================================
     * INSTRUCTIONS
     * =========================================================================================
     * 1) Make the UI look like it does in the mock-up.
     *
     * 2) Logo should fade out or fade in when the user hits the Fade In or Fade Out button
     *
     * 3) User should be able to drag the logo around the screen with his/her fingers
     *
     * 4) Add a bonus to make yourself stick out. Music, color, fireworks, explosions!!! Have Swift experience? Why not write the Animation 
     *    section in Swfit to show off your skills. Anything your heart desires!
     *
     **/
    
    @IBOutlet weak var animationButton: UIButton!
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var logoContainerView: UIView!
  
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Animation"
        self.view.backgroundColor = GlobalConstant.viewBackGroundColor
    
        setupButton()
        setupImageView()
    }
    
     // MARK: - Handle layout and initial look
    func setupImageView(){
        //Have question how to handle logo image with constraint or without. Because :
        // 1- if add autoconstraint then while animating, logoimageview will always jump to centre and then animate.
        //2- if not add autoconstraint logoimageview will animate from place where it is drag.
        //3- for now handle without autoconstraint, but below written code for autoconstraint and commented.
        
        
//        logoImageView.translatesAutoresizingMaskIntoConstraints = false
//        logoImageView.contentMode = .scaleAspectFit
//        logoImageView.clipsToBounds = true
//        logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
//        logoImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
//        logoImageView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.4).isActive = true
//        logoImageView.heightAnchor.constraint(equalTo: logoImageView.widthAnchor, multiplier: 0.4).isActive = true

        logoImageView.isUserInteractionEnabled = true
        addPanRecognizerToImageView()
    }
    
    func setupButton(){
        animationButton.titleLabel?.font = GlobalConstant.buttonTextFont
        animationButton.setTitleColor(GlobalConstant.buttonTextColor, for: .normal)
        animationButton.backgroundColor = GlobalConstant.buttonAndheaderColor
    }
    
    
     // MARK: - Handle drag/drop(Pan) gesture
    func addPanRecognizerToImageView(){
        var panGesture  = UIPanGestureRecognizer()
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(self.panGestureHandler(_:)))
        logoImageView.isUserInteractionEnabled = true
        logoImageView.addGestureRecognizer(panGesture)
    }
    
    @objc func panGestureHandler(_ recogniser: UIPanGestureRecognizer){
        let translation = recogniser.translation(in: view)
        
        guard let gestureView = recogniser.view else {
            return
        }
        
        gestureView.center = CGPoint(
            x: gestureView.center.x + translation.x,
            y: gestureView.center.y + translation.y
        )
        
        recogniser.setTranslation(.zero, in: view)
    }
    
    // MARK: - Actions
    @IBAction func backAction(_ sender: Any) {
        let mainMenuViewController = MenuViewController()
        self.navigationController?.pushViewController(mainMenuViewController, animated: true)
    }
    
    @IBAction func didPressFade(_ sender: Any) {
        if logoImageView.alpha == 1.0 {
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseOut, animations: {
                self.logoImageView.alpha = 0.0
                 self.animationButton.setTitle("FADE OUT", for: .normal)
            }, completion:nil)
           
        }else{
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseIn, animations: {
                self.logoImageView.alpha = 1.0
                self.animationButton.setTitle("FADE IN", for: .normal)
            }, completion: nil)
            
        }
    }
}
