//
//  LoginViewController.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit

class LoginViewController: UIViewController {
    
    /**
     * =========================================================================================
     * INSTRUCTIONS
     * =========================================================================================
     * 1) Make the UI look like it does in the mock-up.
     *
     * 2) Take email and password input from the user
     *
     * 3) Use the endpoint and paramters provided in LoginClient.m to perform the log in
     *
     * 4) Calculate how long the API call took in milliseconds
     *
     * 5) If the response is an error display the error in a UIAlertController
     *
     * 6) If the response is successful display the success message AND how long the API call took in milliseconds in a UIAlertController
     *
     * 7) When login is successful, tapping 'OK' in the UIAlertController should bring you back to the main menu.
     **/
    
    // MARK: - Properties
    private var client: LoginClient?
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Login"
        
        passwordTextField.delegate = self
        emailTextField.delegate = self
        
        client = LoginClient()
        
        setupInitialView()
    }
    
    func setupInitialView(){
        addGestureOnView()
        
        
        loginButton.titleLabel?.font = GlobalConstant.buttonTextFont
        loginButton.setTitleColor(GlobalConstant.buttonTextColor, for: .normal)
        loginButton.backgroundColor = UIColor(red: 14/255.0, green: 92/255.0, blue: 137/255.0, alpha: 1.0)
        
        
        passwordTextField.textColor = GlobalConstant.tittleColor
        passwordTextField.font = GlobalConstant.loginTextFont
        passwordTextField.backgroundColor = GlobalConstant.viewBackGroundColor
        
        emailTextField.textColor = GlobalConstant.tittleColor
        emailTextField.font = GlobalConstant.loginTextFont
        emailTextField.backgroundColor = GlobalConstant.viewBackGroundColor
    
        let attributes = [
            NSAttributedString.Key.foregroundColor: GlobalConstant.loginPlaceHolderColor,
            NSAttributedString.Key.font : GlobalConstant.loginTextFont
        ]
        
        
        passwordTextField.attributedPlaceholder = NSAttributedString(string: "Password",
                                                                     attributes: attributes)
        emailTextField.attributedPlaceholder = NSAttributedString(string: "Email",
                                                                     attributes: attributes)
        
    }
    
    func addGestureOnView(){
        let gesture = UITapGestureRecognizer(target: self, action: Selector("dismissKeyboard"))
        self.view.addGestureRecognizer(gesture)
        gesture.cancelsTouchesInView = true
    }
    
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Actions
    @IBAction func backAction(_ sender: Any) {
        let mainMenuViewController = MenuViewController()
        self.navigationController?.pushViewController(mainMenuViewController, animated: true)
    }
    
    @IBAction func didPressLoginButton(_ sender: Any) {
        var emailEntered = ""
        var passwordEntered = ""
        if let email = emailTextField.text as? String{
            emailEntered = email
        }
        
        if let password = passwordTextField.text as? String{
            passwordEntered = password
        }
        
        
        client?.login(withEmail: emailEntered, password: passwordEntered, completion: { (data) in
            if let dictData = data as? [String : Any]{
                if let error = dictData["error"] as? Int{
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Error Occured", message: "Status code : \(error)", preferredStyle: .alert)
                        
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true)
                    }
                }
                
                if let timeTaken = dictData["success"] as? Double{
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Successfully Login", message: "Time took to login is: \(String(format: "%.3f", timeTaken))", preferredStyle: .alert)

                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: self.backAction))
                        self.present(alert, animated: true)
                    }
                }
            }
        })
    }
}

extension LoginViewController : UITextFieldDelegate{
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
