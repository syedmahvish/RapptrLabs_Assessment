//
//  ChatTableViewCell.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit

class ChatTableViewCell: UITableViewCell {
    
    /**
     * =========================================================================================
     * INSTRUCTIONS
     * =========================================================================================
     * 1) Setup cell to match mockup
     *
     * 2) Include user's avatar image
     **/
    
    // MARK: - Outlets
    @IBOutlet weak var header: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var body: PaddingLabel!
    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentView.backgroundColor = GlobalConstant.viewBackGroundColor
        setUpCellComponents()
        selectionStyle = .none
    }
    
    
    func setUpCellComponents(){
        header.font = GlobalConstant.chatUserNameFont
        header.textColor = GlobalConstant.tittleColor
        
        body.font = GlobalConstant.chatMessageFont
        body.textColor = GlobalConstant.tittleColor
        body.layer.cornerRadius = 8
        body.layer.borderWidth = 1
        body.layer.borderColor = (UIColor(red: 239/255.0, green: 239/255.0, blue: 239/255.0, alpha: 1.0)).cgColor
        
        avatar.layer.masksToBounds = false
        avatar.clipsToBounds = true
        avatar.layer.cornerRadius = avatar.frame.size.height/2
        
    }
    
    // MARK: - Public
    func setCellData(message: Message) {
        if let username = message.username{
            header.text = username
        }
        
        if let bodyText = message.text{
            body.text = bodyText
        }
       
        if let imageurl = message.avatarURL{
            do{
                if let imageData = try Data(contentsOf: imageurl) as? Data,
                   let image = UIImage(data: imageData) as? UIImage{
                        self.avatar.image = image
                }
                
            }catch{
                print("Error while loading image")
            }
        }
    }
}


