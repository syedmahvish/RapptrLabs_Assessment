//
//  ChatClient.m
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

#import "ChatClient.h"

@interface ChatClient ()
@property (nonatomic, strong) NSURLSession *session;
@end

@implementation ChatClient

/**
 * =========================================================================================
 * INSTRUCTIONS
 * =========================================================================================
 * 1) Make a request to fetch chat data used in this app.
 *
 * 2) Using the following endpoint, make a request to fetch data
 *    URL: http://dev.rapptrlabs.com/Tests/scripts/chat_log.php
 **/

- (void)fetchChatData:(void (^)(NSArray<Message *> *))completion withError:(void (^)(NSString *error))errorBlock
{
    NSMutableURLRequest *urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://dev.rapptrlabs.com/Tests/scripts/chat_log.php"]];
    
    [urlRequest setHTTPMethod:@"POST"];
  
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        if(httpResponse.statusCode == 200){
            NSError *parseError = nil;
            NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
            NSMutableArray *messageArray = [[NSMutableArray alloc]init];
            messageArray = [responseDictionary objectForKey:@"data"];
            
            NSMutableArray *messages = [[NSMutableArray alloc]init];
                
            for (NSDictionary *obj in messageArray) {
                    Message *messageObj = [[Message alloc] init];
               
                    messageObj.avatarURL =  [[NSURL alloc]initWithString:[obj objectForKey:@"avatar_url"]];
                    messageObj.text = [[NSString alloc]initWithString:[obj objectForKey:@"message"]];
                    messageObj.username =  [[NSString alloc]initWithString:[obj objectForKey:@"name"]];  //[obj objectForKey:@"name"];
                    messageObj.userID =  [[NSString alloc]initWithString:[obj objectForKey:@"user_id"]]; // [obj objectForKey:@"user_id"];
                    [messages addObject:messageObj];
                }
                
                completion(messages);
                
        }else{
            NSLog(@"Error");
            completion(nil);
            errorBlock(error);
        }
        
    }];
    [dataTask resume];
    
}

@end
