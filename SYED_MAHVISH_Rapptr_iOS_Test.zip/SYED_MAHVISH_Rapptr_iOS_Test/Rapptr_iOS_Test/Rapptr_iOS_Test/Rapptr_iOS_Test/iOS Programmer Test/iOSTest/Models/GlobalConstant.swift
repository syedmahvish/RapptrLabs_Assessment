//
//  GlobalConstant.swift
//  iOSTest
//
//  Created by Mahvish Syed on 22/05/21.
//  Copyright © 2021 D&ATechnologies. All rights reserved.
//

import Foundation
import UIKit

class GlobalConstant {
    
    static let headerTextFont = UIFont.systemFont(ofSize: 17, weight: .semibold)
    static let headerTextColor = UIColor(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1.0)
    
    static let buttonTextFont = UIFont.systemFont(ofSize: 16, weight: .semibold)
    static let buttonTextColor = UIColor(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1.0)
    
    static let chatUserNameFont = UIFont.systemFont(ofSize: 13, weight: .semibold)
    static let chatMessageFont = UIFont.systemFont(ofSize: 15, weight: .regular)
    static let tittleColor = UIColor(red: 27/255.0, green: 30/255.0, blue: 31/255.0, alpha: 1.0)
    
    static let loginTextFont = UIFont.systemFont(ofSize: 16, weight: .regular)
    static let loginPlaceHolderColor = UIColor(red: 95/255.0, green: 96/255.0, blue: 99/255.0, alpha: 1.0)
    
    static let buttonAndheaderColor = UIColor(red: 14/255.0, green: 92/255.0, blue: 137/255.0, alpha: 1.0)
    
    static let viewBackGroundColor = UIColor(red: 249/255.0, green: 249/255.0, blue: 249/255.0, alpha: 1.0)
    
    
    
}
