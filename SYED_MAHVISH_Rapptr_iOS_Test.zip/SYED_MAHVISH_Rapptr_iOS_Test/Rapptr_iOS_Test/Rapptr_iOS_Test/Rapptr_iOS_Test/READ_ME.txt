Hello!

Your task is to use the provided project to create the iOS app displayed in the provided PDF.

You will find more detailed instructions as comments inside of the project.

All required design assets are already inside of the provided project.

Bonus Points:
- Show you can create UI and Auto Layout programmatically as well as through Storyboard/Interface Builder
- Show us you can add Cocoapods to this project. We will allow the use of one single pod.

Good luck!